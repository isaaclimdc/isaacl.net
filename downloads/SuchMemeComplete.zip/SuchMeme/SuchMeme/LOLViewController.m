//
//  LOLViewController.m
//  SuchMeme
//
//  Created by Isaac Lim on 11/1/13.
//  Copyright (c) 2013 isaacl.net. All rights reserved.
//

#import "LOLViewController.h"

#define kMemeBaseURL @"http://api.automeme.net/"
#define kMemeEndpoint @"text.json"
#define kCatAPI @"http://thecatapi.com/api/images/get?format=src&type=jpg&results_per_page=1"
#define kCatImage @"placeholderCat"

@implementation LOLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Futura-Medium" size:16]} forState:UIControlStateNormal];

    [self styleMemeLabel:self.topLabel];
    [self styleMemeLabel:self.bottomLabel];

    self.navigationItem.leftBarButtonItem.enabled = NO;

    self.mainImageView.image = [UIImage imageNamed:kCatImage];

    textClient = [[ILHTTPClient alloc] initWithBaseURL:kMemeBaseURL andView:self.view];
}

- (void)styleMemeLabel:(THLabel *)label
{
    label.font = [UIFont fontWithName:@"Impact" size:30];
    label.textColor = [UIColor whiteColor];
    label.strokeColor = [UIColor blackColor];
    label.strokeSize = 2.0f;
}

- (IBAction)generateRandomMeme:(id)sender
{
    self.navigationItem.leftBarButtonItem.enabled = YES;

    NSURL *catURL = [NSURL URLWithString:kCatAPI];
    [self.mainImageView setImageWithURL:catURL
                       placeholderImage:[UIImage imageNamed:kCatImage]];

    [textClient getPath:kMemeEndpoint
             parameters:@{@"lines" : @"25"}
            loadingText:@"Purr-sing words"
            successText:@"Done!"
                success:^(AFHTTPRequestOperation *operation, id response) {
                    NSArray *responseArr = [response JSONValue];
                    NSLog(@"Success!: %@", responseArr);

                    NSArray *bestMemeHalves = [self pickBestMeme:responseArr];
                    NSAssert(bestMemeHalves.count == 2, @"Meme must be in 2 parts!");
                    [self placeTextTopText:bestMemeHalves[0] bottomText:bestMemeHalves[1]];

                } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                    NSLog(@"Error!: %@", error);
                }];
}

- (void)placeTextTopText:(NSString *)topText bottomText:(NSString *)bottomText
{
    self.topLabel.text = [topText uppercaseString];
    self.bottomLabel.text = [bottomText uppercaseString];
}

- (IBAction)shareAction:(id)sender
{
    UIImage *finalMeme = [self saveToImage];

    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[finalMeme] applicationActivities:nil];
    [self presentViewController:activityVC animated:YES completion:nil];
}

#pragma mark - Helpers

- (NSArray *)pickBestMeme:(NSArray *)possibleMemes
{
    for (NSString *meme in possibleMemes) {
        if ([meme rangeOfString:@"_"].length > 0) continue;

        NSMutableArray *halves = [[meme componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@".,"]] mutableCopy];
        [halves filterUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(NSString *str, NSDictionary *bindings) { return str.length > 0; }]];
        if (halves.count == 2) {
            NSLog(@"Halves: %@", halves);
            return halves;
        }
    }
    return nil;
}

- (UIImage *)saveToImage
{
    UIGraphicsBeginImageContextWithOptions(self.canvas.frame.size, NO, [UIScreen mainScreen].scale);
    [self.canvas drawViewHierarchyInRect:self.canvas.bounds afterScreenUpdates:YES];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
