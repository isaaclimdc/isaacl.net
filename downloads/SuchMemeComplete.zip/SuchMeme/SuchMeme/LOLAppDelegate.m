//
//  LOLAppDelegate.m
//  SuchMeme
//
//  Created by Isaac Lim on 11/1/13.
//  Copyright (c) 2013 isaacl.net. All rights reserved.
//

#import "LOLAppDelegate.h"

@implementation LOLAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithRed:0.0 green:0.7 blue:0.98 alpha:1.0]];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor], NSFontAttributeName: [UIFont fontWithName:@"Futura-CondensedExtraBold" size:24]}];

    self.window.tintColor = [UIColor whiteColor];

    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];

    return YES;
}

@end
