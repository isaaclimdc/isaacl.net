//
//  LOLViewController.h
//  SuchMeme
//
//  Created by Isaac Lim on 11/1/13.
//  Copyright (c) 2013 isaacl.net. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "THLabel.h"
#import "ILHTTPClient.h"
#import "UIImageView+AFNetworking.h"

@interface LOLViewController : UIViewController
{
    ILHTTPClient *textClient;
}

@property (strong, nonatomic) IBOutlet UIView *canvas;
@property (strong, nonatomic) IBOutlet UIImageView *mainImageView;
@property (strong, nonatomic) IBOutlet THLabel *topLabel;
@property (strong, nonatomic) IBOutlet THLabel *bottomLabel;

@end
