//
//  main.m
//  SuchMeme
//
//  Created by Isaac Lim on 11/1/13.
//  Copyright (c) 2013 isaacl.net. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LOLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LOLAppDelegate class]));
    }
}
