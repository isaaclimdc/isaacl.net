//
//  MainViewController.m
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

/* Called when the view is initially loaded */
- (void)viewDidLoad
{
    [super viewDidLoad];
}

#pragma mark - Table View Methods

/* Return the number of sections */
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 0;
}

/* Return the number of rows in the section */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

/* Return the desired height for a row in the table */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 60;
}

/* Set up the contents of the cells in the table */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];

    THEvent *event = [THEvent eventInArray:daysArray atIndexPath:indexPath];
    
    /* Configure the cell here */
    
    
    return cell;
}

/* Return the titles for the headers in each section */
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return nil;
}

/* Called when a row in the table is tapped on */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    THDay *day = [THDay dayInArray:daysArray atIndexPath:indexPath];
    THEvent *event = [THEvent eventInArray:daysArray atIndexPath:indexPath];

    /* Take action here */
    

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Pre-written Methods

/* Pre-written method:
 *     Returns an array with the data objects
 */
- (NSArray *)getScheduleFromFile
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"schedule"
                                                         ofType:@"plist"];

    NSArray *temp = [[NSArray alloc] initWithContentsOfFile:filePath];

    NSMutableArray *result = [NSMutableArray array];

    for (NSDictionary *tempDay in temp) {
        NSString *date = [tempDay objectForKey:@"date"];
        NSMutableArray *events = [NSMutableArray array];

        for (NSDictionary *tempEvent in [tempDay objectForKey:@"events"]) {
            NSString *time = [tempEvent objectForKey:@"time"];
            NSString *title = [tempEvent objectForKey:@"title"];
            THEvent *event = [THEvent newEventWithTime:time andTitle:title];
            [events addObject:event];
        }

        THDay *day = [THDay newDayWithDate:date andEvents:events];
        [result addObject:day];
    }

    return result;
}

/* Pre-written method:
 *     Does the required setup for the navigation bar
 */
- (void)setupNavBar
{
    /* Sets bar to red color */
    self.navigationController.navigationBar.tintColor = [UIColor redColor];

    /* Adds the included TartanHacks image */
    UIImageView *navImg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"banner.png"]];
    CGPoint center = navImg.center;
    center.x = self.navigationController.navigationBar.center.x;
    navImg.center = center;
    [self.navigationController.navigationBar addSubview:navImg];
}

@end
