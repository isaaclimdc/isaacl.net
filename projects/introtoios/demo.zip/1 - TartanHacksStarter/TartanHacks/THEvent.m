//
//  THEvent.m
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import "THEvent.h"

@implementation THEvent

+ (THEvent *)newEventWithTime:(NSString *)time andTitle:(NSString *)title
{
    THEvent *event = [[THEvent alloc] init];
    event.time = time;
    event.title = title;
    return event;
}

+ (THEvent *)eventInArray:(NSArray *)array atIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;

    THDay *day = array[section];
    NSArray *events = day.events;
    THEvent *event = events[row];

    return event;
}

@end
