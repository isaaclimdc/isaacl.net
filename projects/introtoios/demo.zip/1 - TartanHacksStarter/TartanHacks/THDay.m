//
//  THDay.m
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import "THDay.h"

@implementation THDay

+ (THDay *)newDayWithDate:(NSString *)date andEvents:(NSArray *)events
{
    THDay *day = [[THDay alloc] init];
    day.date = date;
    day.events = events;
    return day;
}

+ (THDay *)dayInArray:(NSArray *)array atIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section = indexPath.section;
    THDay *day = array[section];

    return day;
}

@end
