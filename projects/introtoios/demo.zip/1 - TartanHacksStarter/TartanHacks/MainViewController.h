//
//  MainViewController.h
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "THDay.h"
#import "THEvent.h"

@interface MainViewController : UITableViewController

@end
