//
//  main.m
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
