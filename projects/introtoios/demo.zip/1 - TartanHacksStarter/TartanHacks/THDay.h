//
//  THDay.h
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface THDay : NSObject

@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSArray *events;

/* Allocates a new THDay object and assigns it a date and an array of
 * THEvent objects.
 */
+ (THDay *)newDayWithDate:(NSString *)date andEvents:(NSArray *)events;

/* Extracts a THDay object from an array */
+ (THDay *)dayInArray:(NSArray *)array atIndexPath:(NSIndexPath *)indexPath;

@end
