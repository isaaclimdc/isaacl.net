//
//  THEvent.h
//  TartanHacks
//
//  Created by Isaac Lim on 1/17/13.
//  Copyright (c) 2013 tartanhacks.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "THDay.h"

@interface THEvent : NSObject

@property (strong, nonatomic) NSString *time;
@property (strong, nonatomic) NSString *title;

/* Allocates a new THEvent object and assigns it a time and a title */
+ (THEvent *)newEventWithTime:(NSString *)time andTitle:(NSString *)title;

/* Extracts a THEvent object from an array */
+ (THEvent *)eventInArray:(NSArray *)array atIndexPath:(NSIndexPath *)indexPath;

@end
